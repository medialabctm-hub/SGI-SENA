-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: GestionEquipo
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Ambientes`
--

DROP TABLE IF EXISTS `Ambientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Ambientes` (
  `id_ambiente` int NOT NULL AUTO_INCREMENT,
  `codigo_ambiente` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_ambiente` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_ambiente` enum('Laboratorio','Aula','Taller','Oficina','Bodega','Sin Asignar') COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacidad_personas` int DEFAULT NULL,
  `piso` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edificio` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `estado_ambiente` enum('Activo','Inactivo','En Mantenimiento') COLLATE utf8mb4_unicode_ci DEFAULT 'Activo',
  `detalles_uso` json DEFAULT NULL COMMENT 'Historial de uso del ambiente, incluyendo instructores por fecha y clase',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ambiente`),
  UNIQUE KEY `codigo_ambiente` (`codigo_ambiente`),
  KEY `idx_codigo` (`codigo_ambiente`),
  KEY `idx_tipo` (`tipo_ambiente`),
  KEY `idx_estado` (`estado_ambiente`),
  KEY `idx_tipo_estado` (`tipo_ambiente`,`estado_ambiente`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Ubicaciones fÃ­sicas donde se encuentran los equipos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ambientes`
--

LOCK TABLES `Ambientes` WRITE;
/*!40000 ALTER TABLE `Ambientes` DISABLE KEYS */;
INSERT INTO `Ambientes` VALUES (1,'101','Ambiente 101','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(2,'102','Ambiente 102','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(3,'103','Ambiente 103','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(4,'104','Ambiente 104','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(5,'105','Ambiente 105','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(6,'106','Ambiente 106','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(7,'107','Ambiente 107','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(8,'201','Ambiente 201','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(9,'202','Ambiente 202','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(10,'203','Ambiente 203','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(11,'204','Ambiente 204','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(12,'205','Ambiente 205','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(13,'301','Ambiente 301','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(14,'302','Ambiente 302','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(15,'401','Ambiente 401','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(16,'402','Ambiente 402','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(17,'403','Ambiente 403','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(18,'501','Ambiente 501','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(19,'502','Ambiente 502','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(20,'503','Ambiente 503','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(21,'504','Ambiente 504','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(22,'505','Ambiente 505','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(23,'506','Ambiente 506','Aula',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13'),(24,'Sin Asignar','Sin Asignar','Sin Asignar',NULL,NULL,NULL,NULL,'Activo',NULL,'2026-01-27 15:14:13');
/*!40000 ALTER TABLE `Ambientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Aprendices`
--

DROP TABLE IF EXISTS `Aprendices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Aprendices` (
  `id_aprendiz` int NOT NULL AUTO_INCREMENT,
  `ficha` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documento` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_documento` enum('TI','CC','CE','PPT','Otro') COLLATE utf8mb4_unicode_ci DEFAULT 'CC' COMMENT 'Tipo de documento de identidad',
  `tipo_documento_otro` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'EspecificaciÃ³n cuando tipo_documento es "Otro"',
  `jornada` enum('MaÃ±ana','Tarde','Noche') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creado_por` int DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_aprendiz`),
  UNIQUE KEY `uk_documento` (`documento`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_ficha` (`ficha`),
  KEY `idx_jornada` (`jornada`),
  KEY `idx_tipo_documento` (`tipo_documento`),
  CONSTRAINT `Aprendices_ibfk_1` FOREIGN KEY (`creado_por`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro de aprendices (no habilitados para iniciar sesiÃ³n)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Aprendices`
--

LOCK TABLES `Aprendices` WRITE;
/*!40000 ALTER TABLE `Aprendices` DISABLE KEYS */;
/*!40000 ALTER TABLE `Aprendices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Auditoria`
--

DROP TABLE IF EXISTS `Auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Auditoria` (
  `id_auditoria` int NOT NULL AUTO_INCREMENT,
  `tabla_afectada` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operacion` enum('INSERT','UPDATE','DELETE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_registro` int DEFAULT NULL,
  `usuario_accion` int DEFAULT NULL,
  `fecha_accion` datetime DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datos_anteriores` json DEFAULT NULL,
  `datos_nuevos` json DEFAULT NULL,
  PRIMARY KEY (`id_auditoria`),
  KEY `idx_tabla` (`tabla_afectada`),
  KEY `idx_fecha` (`fecha_accion` DESC),
  KEY `idx_usuario_fecha` (`usuario_accion`,`fecha_accion` DESC),
  CONSTRAINT `Auditoria_ibfk_1` FOREIGN KEY (`usuario_accion`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro de auditorÃ­a de cambios en el sistema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Auditoria`
--

LOCK TABLES `Auditoria` WRITE;
/*!40000 ALTER TABLE `Auditoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `Auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Auditoria_Clases`
--

DROP TABLE IF EXISTS `Auditoria_Clases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Auditoria_Clases` (
  `id_auditoria` int NOT NULL AUTO_INCREMENT,
  `id_clase` int NOT NULL,
  `estado_anterior` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado_nuevo` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_cambio` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario_cambio` int DEFAULT NULL,
  `origen` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Origen del cambio: API, Trigger, Stored Procedure, etc.',
  `stack_trace` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_auditoria`),
  KEY `idx_clase_fecha` (`id_clase`,`fecha_cambio` DESC),
  CONSTRAINT `Auditoria_Clases_ibfk_1` FOREIGN KEY (`id_clase`) REFERENCES `Clases` (`id_clase`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AuditorÃ­a de cambios de estado en clases para debugging';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Auditoria_Clases`
--

LOCK TABLES `Auditoria_Clases` WRITE;
/*!40000 ALTER TABLE `Auditoria_Clases` DISABLE KEYS */;
/*!40000 ALTER TABLE `Auditoria_Clases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Categorias_Equipo`
--

DROP TABLE IF EXISTS `Categorias_Equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Categorias_Equipo` (
  `id_categoria` int NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `es_componente` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `nombre_categoria` (`nombre_categoria`),
  KEY `idx_es_componente` (`es_componente`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='CategorÃ­as de equipos (completos o componentes)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Categorias_Equipo`
--

LOCK TABLES `Categorias_Equipo` WRITE;
/*!40000 ALTER TABLE `Categorias_Equipo` DISABLE KEYS */;
INSERT INTO `Categorias_Equipo` VALUES (1,'ADAPTADOR DE RED','Adaptadores de red',0),(2,'ACCES POINT','Puntos de acceso inalÃ¡mbricos',0),(3,'COMPONENTE ELECTRONICO','Componentes electrÃ³nicos diversos',1),(4,'PORTATIL','Computadores portÃ¡tiles',0),(5,'CPU','Unidad central de procesamiento',0),(6,'CPU INTEGRADA CON MONITOR','CPU integrada con monitor',0),(7,'GAFAS DE REALIDAD VIRTUAL','Gafas de realidad virtual',0),(8,'INSUMOS ELECTRICOS','Insumos y materiales elÃ©ctricos',1),(9,'MODEM','MÃ³dems de red',0),(10,'MODULO DE CIRCUITOS','MÃ³dulos de circuitos',1),(11,'MONITOR','Pantallas y monitores',1),(12,'MOTOR','Motores elÃ©ctricos',0),(13,'PROYECTOR','Equipos de proyecciÃ³n',0),(14,'ROUTER O ENRUTADOR','Routers y enrutadores de red',0),(15,'SILLA','Sillas y mobiliario',0),(16,'SISTEMA DE REALIDAD VIRTUAL','Sistemas completos de realidad virtual',0),(17,'SWITCH','Switches de red',0),(18,'TABLET','Tablets y dispositivos mÃ³viles',0),(19,'TABLETA DIGITALIZADORA','Tabletas digitalizadoras',0),(20,'ESTANTE','Estantes y mobiliario',0),(21,'MESA','Mesas y mobiliario',0),(22,'MOUSE','Dispositivos de entrada - Mouse',1),(23,'TECLADO','Dispositivos de entrada - Teclado',1),(24,'AIRE ACONDICIONADO','Equipos de aire acondicionado',0);
/*!40000 ALTER TABLE `Categorias_Equipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Clases`
--

DROP TABLE IF EXISTS `Clases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Clases` (
  `id_clase` int NOT NULL AUTO_INCREMENT,
  `id_ambiente` int NOT NULL,
  `id_instructor` int NOT NULL,
  `nombre_clase` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_ficha` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'CÃ³digo de la ficha o grupo de aprendices',
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `fecha_clase` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `estado_clase` enum('Programada','En Curso','Finalizada','Cancelada') COLLATE utf8mb4_unicode_ci DEFAULT 'Programada',
  `fecha_inicio_real` datetime DEFAULT NULL,
  `fecha_fin_real` datetime DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `creado_por` int DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_clase`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_ambiente_fecha_hora` (`id_ambiente`,`fecha_clase`,`hora_inicio`,`hora_fin`,`estado_clase`),
  KEY `idx_instructor` (`id_instructor`),
  KEY `idx_ficha` (`codigo_ficha`),
  KEY `idx_estado_clase` (`estado_clase`),
  KEY `idx_fecha_clase` (`fecha_clase`),
  KEY `idx_clases_filtros` (`id_instructor`,`fecha_clase`,`estado_clase`,`id_ambiente`),
  KEY `idx_clases_ambiente_fecha` (`id_ambiente`,`fecha_clase` DESC,`hora_inicio`),
  KEY `idx_clases_estado_fecha_hora` (`estado_clase`,`fecha_clase`,`hora_inicio`,`hora_fin`),
  CONSTRAINT `Clases_ibfk_1` FOREIGN KEY (`id_ambiente`) REFERENCES `Ambientes` (`id_ambiente`) ON DELETE RESTRICT,
  CONSTRAINT `Clases_ibfk_2` FOREIGN KEY (`id_instructor`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE RESTRICT,
  CONSTRAINT `Clases_ibfk_3` FOREIGN KEY (`creado_por`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ProgramaciÃ³n de clases en ambientes con horarios especÃ­ficos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Clases`
--

LOCK TABLES `Clases` WRITE;
/*!40000 ALTER TABLE `Clases` DISABLE KEYS */;
/*!40000 ALTER TABLE `Clases` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_auditoria_estado_clase` AFTER UPDATE ON `Clases` FOR EACH ROW BEGIN
    IF OLD.estado_clase <> NEW.estado_clase THEN
        INSERT INTO Auditoria_Clases (
            id_clase,
            estado_anterior,
            estado_nuevo,
            origen,
            stack_trace
        ) VALUES (
            NEW.id_clase,
            OLD.estado_clase,
            NEW.estado_clase,
            'TRIGGER_AUDITORIA',
            CONCAT('Cambio detectado. Usuario: ', IFNULL(@usuario_actual, 'Sistema'), 
                   ' | fecha_inicio_real: ', IFNULL(OLD.fecha_inicio_real, 'NULL'), 
                   ' -> ', IFNULL(NEW.fecha_inicio_real, 'NULL'),
                   ' | fecha_fin_real: ', IFNULL(OLD.fecha_fin_real, 'NULL'), 
                   ' -> ', IFNULL(NEW.fecha_fin_real, 'NULL'))
        );
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Componentes_Asociados`
--

DROP TABLE IF EXISTS `Componentes_Asociados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Componentes_Asociados` (
  `id_asociacion` int NOT NULL AUTO_INCREMENT,
  `codigo_equipo_completo` int NOT NULL,
  `codigo_componente` int NOT NULL,
  `tipo_componente` enum('Mouse','Teclado','Monitor','Torre','Otro') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_asociacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_desvinculacion` datetime DEFAULT NULL,
  `estado_asociacion` enum('Activo','Desvinculado') COLLATE utf8mb4_unicode_ci DEFAULT 'Activo',
  `observaciones` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_asociacion`),
  UNIQUE KEY `uk_componente_activo` (`codigo_componente`,`estado_asociacion`),
  KEY `idx_equipo_completo` (`codigo_equipo_completo`),
  KEY `idx_componente` (`codigo_componente`),
  KEY `idx_estado_asociacion` (`estado_asociacion`),
  CONSTRAINT `Componentes_Asociados_ibfk_1` FOREIGN KEY (`codigo_equipo_completo`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE,
  CONSTRAINT `Componentes_Asociados_ibfk_2` FOREIGN KEY (`codigo_componente`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AsociaciÃ³n de componentes a equipos completos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Componentes_Asociados`
--

LOCK TABLES `Componentes_Asociados` WRITE;
/*!40000 ALTER TABLE `Componentes_Asociados` DISABLE KEYS */;
/*!40000 ALTER TABLE `Componentes_Asociados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Criterios_Asignacion`
--

DROP TABLE IF EXISTS `Criterios_Asignacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Criterios_Asignacion` (
  `id_criterio` int NOT NULL AUTO_INCREMENT,
  `nombre_criterio` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prioridad` int DEFAULT '1',
  `activo` tinyint(1) DEFAULT '1',
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `parametros` json DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_criterio`),
  KEY `idx_activo_prioridad` (`activo`,`prioridad`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Criterios para asignaciÃ³n automÃ¡tica de equipos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Criterios_Asignacion`
--

LOCK TABLES `Criterios_Asignacion` WRITE;
/*!40000 ALTER TABLE `Criterios_Asignacion` DISABLE KEYS */;
INSERT INTO `Criterios_Asignacion` VALUES (1,'Estado FÃ­sico',1,1,'Prioriza equipos en mejor estado fÃ­sico','{\"orden\": [\"Nuevo\", \"Bueno\", \"Regular\"]}','2026-01-27 15:14:13'),(2,'Fecha AdquisiciÃ³n',2,1,'Prioriza equipos mÃ¡s recientes','{\"orden\": \"DESC\"}','2026-01-27 15:14:13'),(3,'Mismo Ambiente',3,1,'Prioriza equipos del mismo ambiente solicitado','{\"peso\": 0.8}','2026-01-27 15:14:13');
/*!40000 ALTER TABLE `Criterios_Asignacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Elementos`
--

DROP TABLE IF EXISTS `Elementos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Elementos` (
  `codigo_equipo` int NOT NULL AUTO_INCREMENT,
  `id_categoria` int NOT NULL,
  `id_ambiente` int NOT NULL,
  `id_cuentadante` int DEFAULT NULL COMMENT 'ID del cuentadante responsable de este equipo',
  `tipo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `fecha_adquisicion` date DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `vida_util_meses` int DEFAULT NULL,
  `estado_fisico` enum('Nuevo','Bueno','Regular','Malo','DaÃ±ado') COLLATE utf8mb4_unicode_ci DEFAULT 'Bueno',
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  `registrado_por` int DEFAULT NULL,
  `specs_completas` text COLLATE utf8mb4_unicode_ci,
  `r_centro` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'CÃ³digo del centro',
  `consecutivo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placa` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `atributos` text COLLATE utf8mb4_unicode_ci,
  `valor_ingreso` decimal(10,2) DEFAULT NULL,
  `cuentadante_principal` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Cuentadante principal permanente',
  PRIMARY KEY (`codigo_equipo`),
  KEY `registrado_por` (`registrado_por`),
  KEY `idx_tipo` (`tipo`),
  KEY `idx_r_centro` (`r_centro`),
  KEY `idx_consecutivo` (`consecutivo`),
  KEY `idx_ambiente` (`id_ambiente`),
  KEY `idx_cuentadante` (`id_cuentadante`),
  KEY `idx_categoria` (`id_categoria`),
  KEY `idx_estado_fisico` (`estado_fisico`),
  KEY `idx_r_centro_consecutivo` (`r_centro`,`consecutivo`),
  KEY `idx_elementos_ambiente_estado` (`id_ambiente`,`estado_fisico`),
  KEY `idx_elementos_cuentadante` (`id_cuentadante`,`estado_fisico`),
  CONSTRAINT `Elementos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `Categorias_Equipo` (`id_categoria`),
  CONSTRAINT `Elementos_ibfk_2` FOREIGN KEY (`id_ambiente`) REFERENCES `Ambientes` (`id_ambiente`) ON DELETE RESTRICT,
  CONSTRAINT `Elementos_ibfk_3` FOREIGN KEY (`id_cuentadante`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE SET NULL,
  CONSTRAINT `Elementos_ibfk_4` FOREIGN KEY (`registrado_por`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabla principal de equipos y componentes tecnolÃ³gicos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Elementos`
--

LOCK TABLES `Elementos` WRITE;
/*!40000 ALTER TABLE `Elementos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Elementos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_historial_cambio_ambiente` AFTER UPDATE ON `Elementos` FOR EACH ROW BEGIN
    IF IFNULL(OLD.id_ambiente, 0) <> IFNULL(NEW.id_ambiente, 0) THEN
        INSERT INTO Historial_Equipos (
            codigo_equipo, tipo_evento, descripcion, id_ambiente_anterior, 
            id_ambiente_nuevo, fecha_evento, registrado_por
        ) VALUES (
            NEW.codigo_equipo, 'Movimiento Ambiente',
            CONCAT('Equipo movido de ambiente ', 
                   IFNULL((SELECT nombre_ambiente FROM Ambientes WHERE id_ambiente = OLD.id_ambiente), 'Sin ambiente'),
                   ' a ',
                   IFNULL((SELECT nombre_ambiente FROM Ambientes WHERE id_ambiente = NEW.id_ambiente), 'Sin ambiente')),
            OLD.id_ambiente, NEW.id_ambiente, NOW(), NEW.registrado_por
        );
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_finalizar_responsabilidades` BEFORE DELETE ON `Elementos` FOR EACH ROW BEGIN
    UPDATE Responsables_Equipo
    SET estado_responsabilidad = 'Finalizado', fecha_desvinculacion = NOW()
    WHERE codigo_equipo = OLD.codigo_equipo AND estado_responsabilidad = 'Activo';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Estado_Equipo`
--

DROP TABLE IF EXISTS `Estado_Equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Estado_Equipo` (
  `codigo_equipo` int NOT NULL,
  `estado_operativo` enum('Disponible','En Uso','En Mantenimiento','DaÃ±ado','Dado de Baja') COLLATE utf8mb4_unicode_ci DEFAULT 'Disponible',
  `detalles` text COLLATE utf8mb4_unicode_ci,
  `fecha_actualizacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `actualizado_por` int DEFAULT NULL,
  PRIMARY KEY (`codigo_equipo`),
  KEY `actualizado_por` (`actualizado_por`),
  KEY `idx_estado` (`estado_operativo`),
  KEY `idx_fecha_actualizacion` (`fecha_actualizacion`),
  KEY `idx_estado_fecha` (`estado_operativo`,`fecha_actualizacion`),
  CONSTRAINT `Estado_Equipo_ibfk_1` FOREIGN KEY (`codigo_equipo`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE,
  CONSTRAINT `Estado_Equipo_ibfk_2` FOREIGN KEY (`actualizado_por`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Estado operativo actual de cada equipo';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Estado_Equipo`
--

LOCK TABLES `Estado_Equipo` WRITE;
/*!40000 ALTER TABLE `Estado_Equipo` DISABLE KEYS */;
/*!40000 ALTER TABLE `Estado_Equipo` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_historial_estado_inicial` AFTER INSERT ON `Estado_Equipo` FOR EACH ROW BEGIN
    INSERT INTO Historial_Equipos (
        codigo_equipo, tipo_evento, descripcion, estado_nuevo, fecha_evento, registrado_por
    ) VALUES (
        NEW.codigo_equipo, 'Cambio Estado', 'Registro inicial del equipo', 
        NEW.estado_operativo, NOW(), NEW.actualizado_por
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_historial_cambio_estado` AFTER UPDATE ON `Estado_Equipo` FOR EACH ROW BEGIN
    IF OLD.estado_operativo <> NEW.estado_operativo THEN
        INSERT INTO Historial_Equipos (
            codigo_equipo, tipo_evento, descripcion, estado_anterior, estado_nuevo, 
            fecha_evento, registrado_por
        ) VALUES (
            NEW.codigo_equipo, 'Cambio Estado',
            CONCAT('Estado cambiado de ', OLD.estado_operativo, ' a ', NEW.estado_operativo),
            OLD.estado_operativo, NEW.estado_operativo, NOW(), NEW.actualizado_por
        );
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Historial_Equipos`
--

DROP TABLE IF EXISTS `Historial_Equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Historial_Equipos` (
  `id_historial` int NOT NULL AUTO_INCREMENT,
  `codigo_equipo` int NOT NULL,
  `tipo_evento` enum('AsignaciÃ³n','DevoluciÃ³n','Mantenimiento','Cambio Estado','Movimiento Ambiente','Otro') COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `id_ambiente_anterior` int DEFAULT NULL,
  `id_ambiente_nuevo` int DEFAULT NULL,
  `estado_anterior` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado_nuevo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_evento` datetime DEFAULT CURRENT_TIMESTAMP,
  `registrado_por` int DEFAULT NULL,
  PRIMARY KEY (`id_historial`),
  KEY `id_ambiente_anterior` (`id_ambiente_anterior`),
  KEY `id_ambiente_nuevo` (`id_ambiente_nuevo`),
  KEY `registrado_por` (`registrado_por`),
  KEY `idx_historial_fecha` (`codigo_equipo`,`fecha_evento` DESC),
  KEY `idx_tipo` (`tipo_evento`),
  KEY `idx_fecha_evento` (`fecha_evento` DESC),
  CONSTRAINT `Historial_Equipos_ibfk_1` FOREIGN KEY (`codigo_equipo`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE,
  CONSTRAINT `Historial_Equipos_ibfk_2` FOREIGN KEY (`id_ambiente_anterior`) REFERENCES `Ambientes` (`id_ambiente`) ON DELETE SET NULL,
  CONSTRAINT `Historial_Equipos_ibfk_3` FOREIGN KEY (`id_ambiente_nuevo`) REFERENCES `Ambientes` (`id_ambiente`) ON DELETE SET NULL,
  CONSTRAINT `Historial_Equipos_ibfk_4` FOREIGN KEY (`registrado_por`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro histÃ³rico de eventos de equipos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Historial_Equipos`
--

LOCK TABLES `Historial_Equipos` WRITE;
/*!40000 ALTER TABLE `Historial_Equipos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Historial_Equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Historial_Uso_Equipos`
--

DROP TABLE IF EXISTS `Historial_Uso_Equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Historial_Uso_Equipos` (
  `id_historial` int NOT NULL AUTO_INCREMENT,
  `codigo_equipo` int NOT NULL,
  `id_usuario` int NOT NULL,
  `nombre_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nombre del usuario en el momento del registro',
  `fecha_hora_inicio` datetime NOT NULL COMMENT 'Fecha y hora en que el usuario iniciÃ³ sesiÃ³n',
  `fecha_hora_fin` datetime DEFAULT NULL COMMENT 'Fecha y hora en que el usuario cerrÃ³ sesiÃ³n. NULL si aÃºn estÃ¡ en uso',
  `estado` enum('En Uso','Finalizado') COLLATE utf8mb4_unicode_ci DEFAULT 'En Uso' COMMENT 'Estado de la sesiÃ³n',
  `duracion_minutos` int DEFAULT NULL COMMENT 'DuraciÃ³n calculada en minutos',
  `observaciones` text COLLATE utf8mb4_unicode_ci COMMENT 'Observaciones adicionales sobre el uso',
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha en que se registrÃ³ el historial',
  `id_clase` int DEFAULT NULL COMMENT 'ID de clase asociada',
  PRIMARY KEY (`id_historial`),
  KEY `idx_equipo` (`codigo_equipo`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_fecha_inicio` (`fecha_hora_inicio` DESC),
  KEY `idx_estado` (`estado`),
  KEY `idx_equipo_fecha` (`codigo_equipo`,`fecha_hora_inicio` DESC),
  KEY `idx_usuario_fecha` (`id_usuario`,`fecha_hora_inicio` DESC),
  KEY `idx_clase` (`id_clase`),
  KEY `idx_historial_uso_usuario_fecha` (`id_usuario`,`fecha_hora_inicio` DESC),
  KEY `idx_historial_uso_equipo_fecha` (`codigo_equipo`,`fecha_hora_inicio` DESC),
  CONSTRAINT `Historial_Uso_Equipos_ibfk_1` FOREIGN KEY (`codigo_equipo`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE,
  CONSTRAINT `Historial_Uso_Equipos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `Historial_Uso_Equipos_ibfk_3` FOREIGN KEY (`id_clase`) REFERENCES `Clases` (`id_clase`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Historial de uso de equipos: registra quiÃ©n iniciÃ³ sesiÃ³n y de quÃ© hora a quÃ© hora';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Historial_Uso_Equipos`
--

LOCK TABLES `Historial_Uso_Equipos` WRITE;
/*!40000 ALTER TABLE `Historial_Uso_Equipos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Historial_Uso_Equipos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `calcular_duracion_uso` BEFORE UPDATE ON `Historial_Uso_Equipos` FOR EACH ROW BEGIN
  IF NEW.fecha_hora_fin IS NOT NULL AND OLD.fecha_hora_fin IS NULL THEN
    SET NEW.duracion_minutos = TIMESTAMPDIFF(MINUTE, NEW.fecha_hora_inicio, NEW.fecha_hora_fin);
    SET NEW.estado = 'Finalizado';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Imagenes_Ambiente`
--

DROP TABLE IF EXISTS `Imagenes_Ambiente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Imagenes_Ambiente` (
  `id_imagen_ambiente` int NOT NULL AUTO_INCREMENT,
  `id_ambiente` int NOT NULL,
  `ruta_imagen` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_archivo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_imagen` enum('Principal','PanorÃ¡mica','Detalle','Plano') COLLATE utf8mb4_unicode_ci DEFAULT 'Detalle',
  `descripcion` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_subida` datetime DEFAULT CURRENT_TIMESTAMP,
  `subida_por` int DEFAULT NULL,
  `es_principal` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_imagen_ambiente`),
  KEY `subida_por` (`subida_por`),
  KEY `idx_ambiente` (`id_ambiente`),
  KEY `idx_principal` (`id_ambiente`,`es_principal`),
  CONSTRAINT `Imagenes_Ambiente_ibfk_1` FOREIGN KEY (`id_ambiente`) REFERENCES `Ambientes` (`id_ambiente`) ON DELETE CASCADE,
  CONSTRAINT `Imagenes_Ambiente_ibfk_2` FOREIGN KEY (`subida_por`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Almacenamiento de rutas de imÃ¡genes de ambientes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Imagenes_Ambiente`
--

LOCK TABLES `Imagenes_Ambiente` WRITE;
/*!40000 ALTER TABLE `Imagenes_Ambiente` DISABLE KEYS */;
/*!40000 ALTER TABLE `Imagenes_Ambiente` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_validar_imagen_principal_ambiente` AFTER INSERT ON `Imagenes_Ambiente` FOR EACH ROW BEGIN
    IF NEW.es_principal = TRUE THEN
        UPDATE Imagenes_Ambiente
        SET es_principal = FALSE
        WHERE id_ambiente = NEW.id_ambiente AND id_imagen_ambiente <> NEW.id_imagen_ambiente;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Imagenes_Equipo`
--

DROP TABLE IF EXISTS `Imagenes_Equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Imagenes_Equipo` (
  `id_imagen_equipo` int NOT NULL AUTO_INCREMENT,
  `codigo_equipo` int NOT NULL,
  `ruta_imagen` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_archivo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_imagen` enum('Principal','Lateral','Detalle','Serie','DaÃ±o') COLLATE utf8mb4_unicode_ci DEFAULT 'Detalle',
  `descripcion` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_subida` datetime DEFAULT CURRENT_TIMESTAMP,
  `subida_por` int DEFAULT NULL,
  `es_principal` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_imagen_equipo`),
  KEY `subida_por` (`subida_por`),
  KEY `idx_equipo` (`codigo_equipo`),
  KEY `idx_principal` (`codigo_equipo`,`es_principal`),
  CONSTRAINT `Imagenes_Equipo_ibfk_1` FOREIGN KEY (`codigo_equipo`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE,
  CONSTRAINT `Imagenes_Equipo_ibfk_2` FOREIGN KEY (`subida_por`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Almacenamiento de rutas de imÃ¡genes de equipos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Imagenes_Equipo`
--

LOCK TABLES `Imagenes_Equipo` WRITE;
/*!40000 ALTER TABLE `Imagenes_Equipo` DISABLE KEYS */;
/*!40000 ALTER TABLE `Imagenes_Equipo` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_validar_imagen_principal_equipo` AFTER INSERT ON `Imagenes_Equipo` FOR EACH ROW BEGIN
    IF NEW.es_principal = TRUE THEN
        UPDATE Imagenes_Equipo
        SET es_principal = FALSE
        WHERE codigo_equipo = NEW.codigo_equipo AND id_imagen_equipo <> NEW.id_imagen_equipo;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Invitation_Codes`
--

DROP TABLE IF EXISTS `Invitation_Codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Invitation_Codes` (
  `id_codigo` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol_destinado` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Rol destinado (referencia a Roles.nombre_rol)',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_expiracion` datetime DEFAULT NULL,
  `max_usos` int DEFAULT '1' COMMENT 'NÃºmero mÃ¡ximo de veces que se puede usar (0 = ilimitado)',
  `usos_actuales` int DEFAULT '0' COMMENT 'NÃºmero de veces que se ha usado',
  `estado` enum('Activo','Inactivo','Expirado','Agotado') COLLATE utf8mb4_unicode_ci DEFAULT 'Activo',
  `creado_por` int DEFAULT NULL,
  PRIMARY KEY (`id_codigo`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_codigo` (`codigo`),
  KEY `idx_rol` (`rol_destinado`),
  KEY `idx_estado` (`estado`),
  KEY `idx_expiracion` (`fecha_expiracion`),
  CONSTRAINT `Invitation_Codes_ibfk_1` FOREIGN KEY (`creado_por`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='CÃ³digos de invitaciÃ³n para registro de usuarios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invitation_Codes`
--

LOCK TABLES `Invitation_Codes` WRITE;
/*!40000 ALTER TABLE `Invitation_Codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `Invitation_Codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mantenimiento`
--

DROP TABLE IF EXISTS `Mantenimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Mantenimiento` (
  `id_mantenimiento` int NOT NULL AUTO_INCREMENT,
  `codigo_equipo` int NOT NULL,
  `tipo_mantenimiento` enum('Preventivo','Correctivo','ActualizaciÃ³n') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_mantenimiento` datetime NOT NULL,
  `fecha_proximo` date DEFAULT NULL,
  `descripcion_trabajo` text COLLATE utf8mb4_unicode_ci,
  `costo` decimal(10,2) DEFAULT NULL,
  `realizado_por` int DEFAULT NULL,
  `id_usuario_tecnico` int DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado_mantenimiento` enum('Programado','En Proceso','Completado','Cancelado') COLLATE utf8mb4_unicode_ci DEFAULT 'Completado',
  PRIMARY KEY (`id_mantenimiento`),
  KEY `realizado_por` (`realizado_por`),
  KEY `id_usuario_tecnico` (`id_usuario_tecnico`),
  KEY `idx_equipo` (`codigo_equipo`),
  KEY `idx_mantenimiento_pendiente` (`estado_mantenimiento`,`fecha_proximo`),
  KEY `idx_fecha` (`fecha_mantenimiento`),
  KEY `idx_fecha_proximo` (`fecha_proximo`),
  KEY `idx_mantenimiento_fecha_proximo` (`fecha_proximo`,`estado_mantenimiento`),
  CONSTRAINT `Mantenimiento_ibfk_1` FOREIGN KEY (`codigo_equipo`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE,
  CONSTRAINT `Mantenimiento_ibfk_2` FOREIGN KEY (`realizado_por`) REFERENCES `Usuarios` (`id_usuario`),
  CONSTRAINT `Mantenimiento_ibfk_3` FOREIGN KEY (`id_usuario_tecnico`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro de mantenimientos realizados y programados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mantenimiento`
--

LOCK TABLES `Mantenimiento` WRITE;
/*!40000 ALTER TABLE `Mantenimiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `Mantenimiento` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_estado_mantenimiento` AFTER INSERT ON `Mantenimiento` FOR EACH ROW BEGIN
    IF NEW.estado_mantenimiento = 'En Proceso' THEN
        UPDATE Estado_Equipo
        SET estado_operativo = 'En Mantenimiento', fecha_actualizacion = NOW()
        WHERE codigo_equipo = NEW.codigo_equipo;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Nombres_Clases`
--

DROP TABLE IF EXISTS `Nombres_Clases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Nombres_Clases` (
  `id_nombre_clase` int NOT NULL AUTO_INCREMENT,
  `nombre_clase` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_normalizado` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creado_por` int NOT NULL,
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_nombre_clase`),
  UNIQUE KEY `uk_nombre_normalizado` (`nombre_normalizado`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_nombre_clase` (`nombre_clase`),
  KEY `idx_activo` (`activo`),
  CONSTRAINT `Nombres_Clases_ibfk_1` FOREIGN KEY (`creado_por`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Nombres de clases validados por administradores para autocompletado';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Nombres_Clases`
--

LOCK TABLES `Nombres_Clases` WRITE;
/*!40000 ALTER TABLE `Nombres_Clases` DISABLE KEYS */;
/*!40000 ALTER TABLE `Nombres_Clases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notificaciones`
--

DROP TABLE IF EXISTS `Notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Notificaciones` (
  `id_notificacion` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `titulo` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cuerpo` text COLLATE utf8mb4_unicode_ci,
  `tipo` enum('info','aviso','alerta','critica') COLLATE utf8mb4_unicode_ci DEFAULT 'info',
  `leida` tinyint(1) DEFAULT '0',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_lectura` datetime DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `creado_por` int DEFAULT NULL,
  PRIMARY KEY (`id_notificacion`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_usuario_leida` (`id_usuario`,`leida`),
  KEY `idx_fecha_notificacion` (`fecha_creacion`),
  KEY `idx_usuario_fecha` (`id_usuario`,`fecha_creacion` DESC),
  KEY `idx_notificaciones_usuario_leida_fecha` (`id_usuario`,`leida`,`fecha_creacion` DESC),
  CONSTRAINT `Notificaciones_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `Notificaciones_ibfk_2` FOREIGN KEY (`creado_por`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Notificaciones del sistema para usuarios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notificaciones`
--

LOCK TABLES `Notificaciones` WRITE;
/*!40000 ALTER TABLE `Notificaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Novedades`
--

DROP TABLE IF EXISTS `Novedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Novedades` (
  `id_novedad` int NOT NULL AUTO_INCREMENT,
  `codigo_equipo` int NOT NULL,
  `tipo_novedad` enum('DaÃ±o','PÃ©rdida','Robo','Mal Funcionamiento','DaÃ±o FÃ­sico','Falta de Componente','Otro') COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_novedad` datetime DEFAULT CURRENT_TIMESTAMP,
  `reportado_por` int NOT NULL,
  `estado_resolucion` enum('Pendiente','En Proceso','Resuelto','No Resuelto') COLLATE utf8mb4_unicode_ci DEFAULT 'Pendiente',
  `fecha_resolucion` datetime DEFAULT NULL,
  `resuelto_por` int DEFAULT NULL,
  `observaciones_resolucion` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_novedad`),
  KEY `reportado_por` (`reportado_por`),
  KEY `resuelto_por` (`resuelto_por`),
  KEY `idx_novedades_pendientes` (`estado_resolucion`,`fecha_novedad`),
  KEY `idx_equipo` (`codigo_equipo`),
  KEY `idx_fecha_novedad` (`fecha_novedad`),
  KEY `idx_novedades_estado_fecha` (`estado_resolucion`,`fecha_novedad` DESC),
  CONSTRAINT `Novedades_ibfk_1` FOREIGN KEY (`codigo_equipo`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE,
  CONSTRAINT `Novedades_ibfk_2` FOREIGN KEY (`reportado_por`) REFERENCES `Usuarios` (`id_usuario`),
  CONSTRAINT `Novedades_ibfk_3` FOREIGN KEY (`resuelto_por`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro de novedades reportadas sobre equipos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Novedades`
--

LOCK TABLES `Novedades` WRITE;
/*!40000 ALTER TABLE `Novedades` DISABLE KEYS */;
/*!40000 ALTER TABLE `Novedades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Participantes_Clase`
--

DROP TABLE IF EXISTS `Participantes_Clase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Participantes_Clase` (
  `id_participante` int NOT NULL AUTO_INCREMENT,
  `id_clase` int NOT NULL,
  `id_aprendiz` int NOT NULL,
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  `presente` tinyint(1) DEFAULT '1',
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_participante`),
  UNIQUE KEY `uk_clase_aprendiz` (`id_clase`,`id_aprendiz`),
  KEY `idx_clase` (`id_clase`),
  KEY `idx_aprendiz` (`id_aprendiz`),
  KEY `idx_participantes_clase_presente` (`id_clase`,`presente`),
  CONSTRAINT `Participantes_Clase_ibfk_1` FOREIGN KEY (`id_clase`) REFERENCES `Clases` (`id_clase`) ON DELETE CASCADE,
  CONSTRAINT `Participantes_Clase_ibfk_2` FOREIGN KEY (`id_aprendiz`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro de aprendices que participan en cada clase';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Participantes_Clase`
--

LOCK TABLES `Participantes_Clase` WRITE;
/*!40000 ALTER TABLE `Participantes_Clase` DISABLE KEYS */;
/*!40000 ALTER TABLE `Participantes_Clase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Permisos`
--

DROP TABLE IF EXISTS `Permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Permisos` (
  `id_permiso` int NOT NULL AUTO_INCREMENT,
  `codigo_permiso` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'CÃ³digo Ãºnico del permiso (ej: users:view)',
  `modulo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'MÃ³dulo al que pertenece (ej: USERS, EQUIPOS)',
  `accion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'AcciÃ³n del permiso (ej: VIEW, CREATE)',
  `descripcion` text COLLATE utf8mb4_unicode_ci COMMENT 'DescripciÃ³n del permiso',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_permiso`),
  UNIQUE KEY `codigo_permiso` (`codigo_permiso`),
  KEY `idx_modulo` (`modulo`),
  KEY `idx_codigo` (`codigo_permiso`),
  KEY `idx_modulo_accion` (`modulo`,`accion`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Permisos disponibles en el sistema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Permisos`
--

LOCK TABLES `Permisos` WRITE;
/*!40000 ALTER TABLE `Permisos` DISABLE KEYS */;
INSERT INTO `Permisos` VALUES (1,'users:view','USERS','VIEW','Ver listado de usuarios','2026-01-27 15:14:13'),(2,'users:view_detail','USERS','VIEW_DETAIL','Ver detalle de un usuario','2026-01-27 15:14:13'),(3,'users:create','USERS','CREATE','Crear nuevos usuarios','2026-01-27 15:14:13'),(4,'users:update','USERS','UPDATE','Editar usuarios','2026-01-27 15:14:13'),(5,'users:delete','USERS','DELETE','Eliminar usuarios','2026-01-27 15:14:13'),(6,'users:manage_roles','USERS','MANAGE_ROLES','Cambiar roles de usuarios','2026-01-27 15:14:13'),(7,'equipos:view','EQUIPOS','VIEW','Ver listado de equipos','2026-01-27 15:14:13'),(8,'equipos:view_detail','EQUIPOS','VIEW_DETAIL','Ver detalle de equipo','2026-01-27 15:14:13'),(9,'equipos:view_own','EQUIPOS','VIEW_OWN','Ver solo equipos asignados','2026-01-27 15:14:13'),(10,'equipos:create','EQUIPOS','CREATE','Registrar nuevos equipos','2026-01-27 15:14:13'),(11,'equipos:update','EQUIPOS','UPDATE','Editar equipos','2026-01-27 15:14:13'),(12,'equipos:delete','EQUIPOS','DELETE','Eliminar equipos','2026-01-27 15:14:13'),(13,'equipos:assign','EQUIPOS','ASSIGN','Asignar equipos a cualquier usuario','2026-01-27 15:14:13'),(14,'equipos:assign_to_aprendiz','EQUIPOS','ASSIGN_TO_APRENDIZ','Asignar solo a aprendices','2026-01-27 15:14:13'),(15,'equipos:manage_categories','EQUIPOS','MANAGE_CATEGORIES','Gestionar categorÃ­as de equipos','2026-01-27 15:14:13'),(16,'novedades:view','NOVEDADES','VIEW','Ver todas las novedades','2026-01-27 15:14:13'),(17,'novedades:view_own','NOVEDADES','VIEW_OWN','Ver solo novedades de equipos propios','2026-01-27 15:14:13'),(18,'novedades:create','NOVEDADES','CREATE','Registrar novedades','2026-01-27 15:14:13'),(19,'novedades:create_own','NOVEDADES','CREATE_OWN','Registrar solo en equipos propios','2026-01-27 15:14:13'),(20,'novedades:update','NOVEDADES','UPDATE','Editar novedades','2026-01-27 15:14:13'),(21,'novedades:delete','NOVEDADES','DELETE','Eliminar novedades','2026-01-27 15:14:13'),(22,'novedades:resolve','NOVEDADES','RESOLVE','Resolver novedades','2026-01-27 15:14:13'),(23,'mantenimiento:view','MANTENIMIENTO','VIEW','Ver historial de mantenimiento','2026-01-27 15:14:13'),(24,'mantenimiento:view_own','MANTENIMIENTO','VIEW_OWN','Ver mantenimiento de equipos propios','2026-01-27 15:14:13'),(25,'mantenimiento:create','MANTENIMIENTO','CREATE','Programar mantenimiento','2026-01-27 15:14:13'),(26,'mantenimiento:update','MANTENIMIENTO','UPDATE','Editar mantenimiento','2026-01-27 15:14:13'),(27,'mantenimiento:delete','MANTENIMIENTO','DELETE','Eliminar registro de mantenimiento','2026-01-27 15:14:13'),(28,'reportes:view','REPORTES','VIEW','Ver reportes','2026-01-27 15:14:13'),(29,'reportes:create','REPORTES','CREATE','Crear reportes','2026-01-27 15:14:13'),(30,'reportes:update','REPORTES','UPDATE','Actualizar reportes','2026-01-27 15:14:13'),(31,'reportes:delete','REPORTES','DELETE','Eliminar reportes','2026-01-27 15:14:13'),(32,'reportes:export','REPORTES','EXPORT','Exportar reportes','2026-01-27 15:14:13'),(33,'ambientes:view','AMBIENTES','VIEW','Ver ambientes','2026-01-27 15:14:13'),(34,'ambientes:create','AMBIENTES','CREATE','Crear ambientes','2026-01-27 15:14:13'),(35,'ambientes:update','AMBIENTES','UPDATE','Editar ambientes','2026-01-27 15:14:13'),(36,'ambientes:delete','AMBIENTES','DELETE','Eliminar ambientes','2026-01-27 15:14:13'),(37,'clases:view','CLASES','VIEW','Ver clases','2026-01-27 15:14:13'),(38,'clases:create','CLASES','CREATE','Crear clases','2026-01-27 15:14:13'),(39,'clases:update','CLASES','UPDATE','Actualizar/iniciar/finalizar clases','2026-01-27 15:14:13'),(40,'clases:delete','CLASES','DELETE','Eliminar clases','2026-01-27 15:14:13'),(41,'notificaciones:view','NOTIFICACIONES','VIEW','Ver propias notificaciones','2026-01-27 15:14:13'),(42,'notificaciones:create','NOTIFICACIONES','CREATE','Crear notificaciones para otros','2026-01-27 15:14:13'),(43,'notificaciones:broadcast','NOTIFICACIONES','BROADCAST','Enviar notificaciones globales','2026-01-27 15:14:13'),(44,'system:view_config','SYSTEM','VIEW_CONFIG','Ver configuraciÃ³n','2026-01-27 15:14:13'),(45,'system:update_config','SYSTEM','UPDATE_CONFIG','Modificar configuraciÃ³n','2026-01-27 15:14:13'),(46,'system:view_audit','SYSTEM','VIEW_AUDIT','Ver auditorÃ­a','2026-01-27 15:14:13'),(47,'roles:manage','ROLES','MANAGE','Gestionar roles y permisos','2026-01-27 15:14:13');
/*!40000 ALTER TABLE `Permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Preferencias_Usuario`
--

DROP TABLE IF EXISTS `Preferencias_Usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Preferencias_Usuario` (
  `id_preferencia` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `notificaciones_email` tinyint(1) DEFAULT '1',
  `notificaciones_sms` tinyint(1) DEFAULT '0',
  `notificaciones_app` tinyint(1) DEFAULT '1',
  `idioma` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'es',
  `zona_horaria` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'America/Bogota',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_preferencia`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  KEY `idx_usuario` (`id_usuario`),
  CONSTRAINT `Preferencias_Usuario_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Preferencias de configuraciÃ³n de usuario';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Preferencias_Usuario`
--

LOCK TABLES `Preferencias_Usuario` WRITE;
/*!40000 ALTER TABLE `Preferencias_Usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `Preferencias_Usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Responsabilidades_Ambiente`
--

DROP TABLE IF EXISTS `Responsabilidades_Ambiente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Responsabilidades_Ambiente` (
  `id_responsabilidad_ambiente` int NOT NULL AUTO_INCREMENT,
  `id_ambiente` int NOT NULL,
  `id_clase` int DEFAULT NULL,
  `jornada` enum('MaÃ±ana','Tarde','Noche') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Jornada de la asignaciÃ³n. NULL para asignaciones temporales',
  `id_usuario` int NOT NULL,
  `tipo_responsabilidad` enum('Principal','Secundario') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `estado_responsabilidad` enum('Activa','Finalizada') COLLATE utf8mb4_unicode_ci DEFAULT 'Activa',
  `asignacion_automatica` tinyint(1) DEFAULT '0' COMMENT 'Indica si fue asignada automÃ¡ticamente por horario',
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `creado_por` int DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `dias_semana` json DEFAULT NULL COMMENT 'Array de dÃ­as de la semana',
  `hora_inicio` time DEFAULT NULL COMMENT 'Hora de inicio del horario',
  `hora_fin` time DEFAULT NULL COMMENT 'Hora de fin del horario',
  PRIMARY KEY (`id_responsabilidad_ambiente`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_ambiente_fecha_activa` (`id_ambiente`,`fecha_inicio`,`fecha_fin`,`estado_responsabilidad`),
  KEY `idx_clase` (`id_clase`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_ambiente_jornada` (`id_ambiente`,`jornada`,`estado_responsabilidad`),
  KEY `idx_ambiente_horas` (`id_ambiente`,`hora_inicio`,`hora_fin`,`estado_responsabilidad`),
  KEY `idx_usuario_horas` (`id_usuario`,`hora_inicio`,`hora_fin`,`estado_responsabilidad`),
  KEY `idx_resp_ambiente_usuario_estado` (`id_usuario`,`estado_responsabilidad`,`id_ambiente`),
  KEY `idx_resp_ambiente_ambiente_estado` (`id_ambiente`,`estado_responsabilidad`,`id_usuario`),
  CONSTRAINT `Responsabilidades_Ambiente_ibfk_1` FOREIGN KEY (`id_ambiente`) REFERENCES `Ambientes` (`id_ambiente`) ON DELETE CASCADE,
  CONSTRAINT `Responsabilidades_Ambiente_ibfk_2` FOREIGN KEY (`id_clase`) REFERENCES `Clases` (`id_clase`) ON DELETE SET NULL,
  CONSTRAINT `Responsabilidades_Ambiente_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `Responsabilidades_Ambiente_ibfk_4` FOREIGN KEY (`creado_por`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Responsabilidades temporales sobre el inventario de un ambiente durante clases';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Responsabilidades_Ambiente`
--

LOCK TABLES `Responsabilidades_Ambiente` WRITE;
/*!40000 ALTER TABLE `Responsabilidades_Ambiente` DISABLE KEYS */;
/*!40000 ALTER TABLE `Responsabilidades_Ambiente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Responsables_Equipo`
--

DROP TABLE IF EXISTS `Responsables_Equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Responsables_Equipo` (
  `id_responsable` int NOT NULL AUTO_INCREMENT,
  `codigo_equipo` int NOT NULL,
  `id_usuario` int DEFAULT NULL COMMENT 'NULL si es registro externo',
  `fecha_asignacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_desvinculacion` datetime DEFAULT NULL,
  `estado_responsabilidad` enum('Activo','Finalizado') COLLATE utf8mb4_unicode_ci DEFAULT 'Activo',
  `tipo_responsabilidad` enum('Principal','Secundario') COLLATE utf8mb4_unicode_ci DEFAULT 'Principal',
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `asignado_por` int DEFAULT NULL,
  `ficha` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'NÃºmero de ficha del aprendiz (registro externo)',
  `nombre_externo` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nombre completo del usuario (registro externo)',
  `documento_externo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Documento del responsable externo',
  `dias_semana` json DEFAULT NULL COMMENT 'Array de dÃ­as de la semana para horarios',
  `hora_inicio` time DEFAULT NULL COMMENT 'Hora de inicio del horario',
  `hora_fin` time DEFAULT NULL COMMENT 'Hora de fin del horario',
  PRIMARY KEY (`id_responsable`),
  KEY `asignado_por` (`asignado_por`),
  KEY `idx_equipo_activo` (`codigo_equipo`,`estado_responsabilidad`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_responsables_activos` (`estado_responsabilidad`,`fecha_asignacion`),
  KEY `idx_ficha` (`ficha`),
  KEY `idx_documento_externo` (`documento_externo`),
  KEY `idx_horarios` (`hora_inicio`,`hora_fin`,`estado_responsabilidad`),
  KEY `idx_resp_equipo_usuario_estado` (`id_usuario`,`estado_responsabilidad`),
  CONSTRAINT `Responsables_Equipo_ibfk_1` FOREIGN KEY (`codigo_equipo`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE,
  CONSTRAINT `Responsables_Equipo_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `Responsables_Equipo_ibfk_3` FOREIGN KEY (`asignado_por`) REFERENCES `Usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='GestiÃ³n de mÃºltiples responsables por equipo';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Responsables_Equipo`
--

LOCK TABLES `Responsables_Equipo` WRITE;
/*!40000 ALTER TABLE `Responsables_Equipo` DISABLE KEYS */;
/*!40000 ALTER TABLE `Responsables_Equipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rol_Permisos`
--

DROP TABLE IF EXISTS `Rol_Permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Rol_Permisos` (
  `id_rol` int NOT NULL,
  `id_permiso` int NOT NULL,
  `activo` tinyint(1) DEFAULT '1' COMMENT 'Indica si el permiso estÃ¡ activo para el rol',
  `fecha_asignacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `asignado_por` int DEFAULT NULL COMMENT 'Usuario que asignÃ³ el permiso',
  PRIMARY KEY (`id_rol`,`id_permiso`),
  KEY `asignado_por` (`asignado_por`),
  KEY `idx_rol_activo` (`id_rol`,`activo`),
  KEY `idx_permiso_activo` (`id_permiso`,`activo`),
  CONSTRAINT `Rol_Permisos_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `Roles` (`id_rol`) ON DELETE CASCADE,
  CONSTRAINT `Rol_Permisos_ibfk_2` FOREIGN KEY (`id_permiso`) REFERENCES `Permisos` (`id_permiso`) ON DELETE CASCADE,
  CONSTRAINT `Rol_Permisos_ibfk_3` FOREIGN KEY (`asignado_por`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='RelaciÃ³n entre roles y permisos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rol_Permisos`
--

LOCK TABLES `Rol_Permisos` WRITE;
/*!40000 ALTER TABLE `Rol_Permisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Rol_Permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Roles`
--

DROP TABLE IF EXISTS `Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Roles` (
  `id_rol` int NOT NULL AUTO_INCREMENT,
  `nombre_rol` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nombre del rol (permite roles personalizados)',
  `descripcion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('Activo','Inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'Activo' COMMENT 'Estado del rol',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `nombre_rol` (`nombre_rol`),
  KEY `idx_estado` (`estado`),
  KEY `idx_nombre` (`nombre_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Roles del sistema de gestiÃ³n de equipos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Roles`
--

LOCK TABLES `Roles` WRITE;
/*!40000 ALTER TABLE `Roles` DISABLE KEYS */;
INSERT INTO `Roles` VALUES (1,'Administrador','Acceso total al sistema','Activo','2026-01-27 15:14:13'),(2,'Instructor','GestiÃ³n de equipos y asignaciones','Activo','2026-01-27 15:14:13'),(3,'Aprendiz','Consulta y uso de equipos asignados','Activo','2026-01-27 15:14:13'),(4,'Cuentadante','Cuentadante responsable de su inventario asignado','Activo','2026-01-27 15:14:13');
/*!40000 ALTER TABLE `Roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tokens_Recuperacion_Contrasena`
--

DROP TABLE IF EXISTS `Tokens_Recuperacion_Contrasena`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Tokens_Recuperacion_Contrasena` (
  `id_token` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_expiracion` datetime NOT NULL,
  `usado` tinyint(1) DEFAULT '0',
  `fecha_uso` datetime DEFAULT NULL,
  PRIMARY KEY (`id_token`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_token` (`token`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_expiracion_usado` (`fecha_expiracion`,`usado`),
  KEY `idx_usuario_expiracion` (`id_usuario`,`fecha_expiracion`,`usado`),
  CONSTRAINT `Tokens_Recuperacion_Contrasena_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tokens para recuperaciÃ³n de contraseÃ±as de usuarios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tokens_Recuperacion_Contrasena`
--

LOCK TABLES `Tokens_Recuperacion_Contrasena` WRITE;
/*!40000 ALTER TABLE `Tokens_Recuperacion_Contrasena` DISABLE KEYS */;
/*!40000 ALTER TABLE `Tokens_Recuperacion_Contrasena` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuarios`
--

DROP TABLE IF EXISTS `Usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_documento` enum('TI','CC','CE','PPT','Otro') COLLATE utf8mb4_unicode_ci DEFAULT 'CC' COMMENT 'Tipo de documento de identidad',
  `tipo_documento_otro` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'EspecificaciÃ³n cuando tipo_documento es "Otro"',
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contrasena` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_rol` int NOT NULL,
  `estado` enum('Activo','Inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'Activo',
  `requiere_cambio_contrasena` tinyint(1) DEFAULT '0' COMMENT 'Indica si el usuario debe cambiar su contraseÃ±a',
  `foto_perfil` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Ruta de la foto de perfil del usuario',
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  `ultimo_acceso` datetime DEFAULT NULL,
  `creado_por` int DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `cedula` (`cedula`),
  UNIQUE KEY `correo` (`correo`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_cedula` (`cedula`),
  KEY `idx_correo` (`correo`),
  KEY `idx_estado` (`estado`),
  KEY `idx_rol` (`id_rol`),
  KEY `idx_estado_rol` (`estado`,`id_rol`),
  KEY `idx_tipo_documento` (`tipo_documento`),
  KEY `idx_usuarios_estado_rol` (`estado`,`id_rol`),
  CONSTRAINT `Usuarios_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `Roles` (`id_rol`),
  CONSTRAINT `Usuarios_ibfk_2` FOREIGN KEY (`creado_por`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Usuarios del sistema con sus credenciales y datos personales';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuarios`
--

LOCK TABLES `Usuarios` WRITE;
/*!40000 ALTER TABLE `Usuarios` DISABLE KEYS */;
INSERT INTO `Usuarios` VALUES (1,'Administrador Sistema','1000000000','CC',NULL,'3001234567','admin@sena.edu.co','$2a$12$zz2nWS1PBuSGeX4gNQS5..Jk8Juo5gb8r8ZYDNZreGcND1jrHlVzq',1,'Activo',0,NULL,'2026-01-27 15:14:13',NULL,NULL);
/*!40000 ALTER TABLE `Usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Verificaciones_Inventario`
--

DROP TABLE IF EXISTS `Verificaciones_Inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Verificaciones_Inventario` (
  `id_verificacion` int NOT NULL AUTO_INCREMENT,
  `codigo_equipo` int NOT NULL,
  `id_ambiente` int DEFAULT NULL COMMENT 'Ambiente donde se verificÃ³ el equipo',
  `id_clase` int DEFAULT NULL COMMENT 'Clase/horario activo cuando se verificÃ³',
  `id_responsabilidad_ambiente` int DEFAULT NULL COMMENT 'Responsabilidad que estaba activa',
  `jornada` enum('MaÃ±ana','Tarde','Noche') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Jornada cuando se verificÃ³',
  `id_usuario` int NOT NULL COMMENT 'Instructor que realiza la verificaciÃ³n',
  `estado_verificacion` enum('Verificado','Con Novedad','No Verificado') COLLATE utf8mb4_unicode_ci NOT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `fecha_verificacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_verificacion`),
  KEY `id_responsabilidad_ambiente` (`id_responsabilidad_ambiente`),
  KEY `idx_equipo_usuario_fecha` (`codigo_equipo`,`id_usuario`,`fecha_verificacion` DESC),
  KEY `idx_ambiente_fecha` (`id_ambiente`,`fecha_verificacion` DESC),
  KEY `idx_clase_fecha` (`id_clase`,`fecha_verificacion` DESC),
  KEY `idx_estado` (`estado_verificacion`),
  KEY `idx_verif_inventario_filtros` (`id_usuario`,`id_ambiente`,`fecha_verificacion` DESC),
  KEY `idx_verif_inventario_equipo_fecha` (`codigo_equipo`,`fecha_verificacion` DESC),
  CONSTRAINT `Verificaciones_Inventario_ibfk_1` FOREIGN KEY (`codigo_equipo`) REFERENCES `Elementos` (`codigo_equipo`) ON DELETE CASCADE,
  CONSTRAINT `Verificaciones_Inventario_ibfk_2` FOREIGN KEY (`id_ambiente`) REFERENCES `Ambientes` (`id_ambiente`) ON DELETE SET NULL,
  CONSTRAINT `Verificaciones_Inventario_ibfk_3` FOREIGN KEY (`id_clase`) REFERENCES `Clases` (`id_clase`) ON DELETE SET NULL,
  CONSTRAINT `Verificaciones_Inventario_ibfk_4` FOREIGN KEY (`id_responsabilidad_ambiente`) REFERENCES `Responsabilidades_Ambiente` (`id_responsabilidad_ambiente`) ON DELETE SET NULL,
  CONSTRAINT `Verificaciones_Inventario_ibfk_5` FOREIGN KEY (`id_usuario`) REFERENCES `Usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Historial completo de verificaciones de inventario con contexto';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Verificaciones_Inventario`
--

LOCK TABLES `Verificaciones_Inventario` WRITE;
/*!40000 ALTER TABLE `Verificaciones_Inventario` DISABLE KEYS */;
/*!40000 ALTER TABLE `Verificaciones_Inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `Vista_Ambientes_Con_Equipos`
--

DROP TABLE IF EXISTS `Vista_Ambientes_Con_Equipos`;
/*!50001 DROP VIEW IF EXISTS `Vista_Ambientes_Con_Equipos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `Vista_Ambientes_Con_Equipos` AS SELECT 
 1 AS `id_ambiente`,
 1 AS `codigo_ambiente`,
 1 AS `nombre_ambiente`,
 1 AS `tipo_ambiente`,
 1 AS `capacidad_personas`,
 1 AS `estado_ambiente`,
 1 AS `total_equipos`,
 1 AS `equipos_disponibles`,
 1 AS `equipos_en_uso`,
 1 AS `total_imagenes`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `Vista_Equipos_Con_Responsables`
--

DROP TABLE IF EXISTS `Vista_Equipos_Con_Responsables`;
/*!50001 DROP VIEW IF EXISTS `Vista_Equipos_Con_Responsables`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `Vista_Equipos_Con_Responsables` AS SELECT 
 1 AS `codigo_equipo`,
 1 AS `r_centro`,
 1 AS `consecutivo`,
 1 AS `tipo`,
 1 AS `modelo`,
 1 AS `nombre_ambiente`,
 1 AS `codigo_ambiente`,
 1 AS `estado_operativo`,
 1 AS `estado_fisico`,
 1 AS `responsables`,
 1 AS `total_responsables`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `Vista_Equipos_Disponibles`
--

DROP TABLE IF EXISTS `Vista_Equipos_Disponibles`;
/*!50001 DROP VIEW IF EXISTS `Vista_Equipos_Disponibles`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `Vista_Equipos_Disponibles` AS SELECT 
 1 AS `codigo_equipo`,
 1 AS `r_centro`,
 1 AS `consecutivo`,
 1 AS `tipo`,
 1 AS `modelo`,
 1 AS `nombre_tipo`,
 1 AS `nombre_ambiente`,
 1 AS `codigo_ambiente`,
 1 AS `tipo_ambiente`,
 1 AS `estado_fisico`,
 1 AS `fecha_adquisicion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `Vista_Equipos_Por_Usuario`
--

DROP TABLE IF EXISTS `Vista_Equipos_Por_Usuario`;
/*!50001 DROP VIEW IF EXISTS `Vista_Equipos_Por_Usuario`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `Vista_Equipos_Por_Usuario` AS SELECT 
 1 AS `id_usuario`,
 1 AS `nombre_usuario`,
 1 AS `cedula`,
 1 AS `nombre_rol`,
 1 AS `equipos_asignados`,
 1 AS `detalle_equipos`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `Vista_Mantenimientos_Proximos`
--

DROP TABLE IF EXISTS `Vista_Mantenimientos_Proximos`;
/*!50001 DROP VIEW IF EXISTS `Vista_Mantenimientos_Proximos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `Vista_Mantenimientos_Proximos` AS SELECT 
 1 AS `id_mantenimiento`,
 1 AS `codigo_equipo`,
 1 AS `r_centro`,
 1 AS `consecutivo`,
 1 AS `tipo`,
 1 AS `tipo_mantenimiento`,
 1 AS `fecha_proximo`,
 1 AS `dias_restantes`,
 1 AS `nombre_ambiente`,
 1 AS `codigo_ambiente`,
 1 AS `prioridad`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `Vista_Responsables_Actuales`
--

DROP TABLE IF EXISTS `Vista_Responsables_Actuales`;
/*!50001 DROP VIEW IF EXISTS `Vista_Responsables_Actuales`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `Vista_Responsables_Actuales` AS SELECT 
 1 AS `id_responsabilidad_ambiente`,
 1 AS `id_ambiente`,
 1 AS `nombre_ambiente`,
 1 AS `codigo_ambiente`,
 1 AS `id_usuario`,
 1 AS `nombre_usuario`,
 1 AS `cedula`,
 1 AS `nombre_rol`,
 1 AS `tipo_responsabilidad`,
 1 AS `fecha_inicio`,
 1 AS `fecha_fin`,
 1 AS `id_clase`,
 1 AS `nombre_clase`,
 1 AS `codigo_ficha`,
 1 AS `fecha_clase`,
 1 AS `hora_inicio`,
 1 AS `hora_fin`,
 1 AS `estado_actual`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `pedidos_externos`
--

DROP TABLE IF EXISTS `pedidos_externos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos_externos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Usuario que realiza el pedido (identificador externo)',
  `id_ambiente` int NOT NULL COMMENT 'ID del ambiente donde se realiza el pedido',
  `ficha` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Ficha asociada al pedido',
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Estado del pedido',
  `fecha_recepcion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha y hora de recepciÃ³n del webhook',
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario`),
  KEY `idx_ambiente` (`id_ambiente`),
  KEY `idx_ficha` (`ficha`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha_recepcion` (`fecha_recepcion` DESC),
  CONSTRAINT `pedidos_externos_ibfk_1` FOREIGN KEY (`id_ambiente`) REFERENCES `Ambientes` (`id_ambiente`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabla para almacenar pedidos recibidos de sistemas externos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos_externos`
--

LOCK TABLES `pedidos_externos` WRITE;
/*!40000 ALTER TABLE `pedidos_externos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos_externos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `Vista_Ambientes_Con_Equipos`
--

/*!50001 DROP VIEW IF EXISTS `Vista_Ambientes_Con_Equipos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Vista_Ambientes_Con_Equipos` AS select `a`.`id_ambiente` AS `id_ambiente`,`a`.`codigo_ambiente` AS `codigo_ambiente`,`a`.`nombre_ambiente` AS `nombre_ambiente`,`a`.`tipo_ambiente` AS `tipo_ambiente`,`a`.`capacidad_personas` AS `capacidad_personas`,`a`.`estado_ambiente` AS `estado_ambiente`,count(distinct `e`.`codigo_equipo`) AS `total_equipos`,count(distinct (case when (`ee`.`estado_operativo` = 'Disponible') then `e`.`codigo_equipo` end)) AS `equipos_disponibles`,count(distinct (case when (`ee`.`estado_operativo` = 'En Uso') then `e`.`codigo_equipo` end)) AS `equipos_en_uso`,count(distinct `ia`.`id_imagen_ambiente`) AS `total_imagenes` from (((`Ambientes` `a` left join `Elementos` `e` on((`a`.`id_ambiente` = `e`.`id_ambiente`))) left join `Estado_Equipo` `ee` on((`e`.`codigo_equipo` = `ee`.`codigo_equipo`))) left join `Imagenes_Ambiente` `ia` on((`a`.`id_ambiente` = `ia`.`id_ambiente`))) group by `a`.`id_ambiente`,`a`.`codigo_ambiente`,`a`.`nombre_ambiente`,`a`.`tipo_ambiente`,`a`.`capacidad_personas`,`a`.`estado_ambiente` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Vista_Equipos_Con_Responsables`
--

/*!50001 DROP VIEW IF EXISTS `Vista_Equipos_Con_Responsables`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Vista_Equipos_Con_Responsables` AS select `e`.`codigo_equipo` AS `codigo_equipo`,`e`.`r_centro` AS `r_centro`,`e`.`consecutivo` AS `consecutivo`,`e`.`tipo` AS `tipo`,`e`.`modelo` AS `modelo`,`a`.`nombre_ambiente` AS `nombre_ambiente`,`a`.`codigo_ambiente` AS `codigo_ambiente`,`ee`.`estado_operativo` AS `estado_operativo`,`e`.`estado_fisico` AS `estado_fisico`,group_concat(concat(`u`.`nombre_usuario`,' (',`r`.`nombre_rol`,')') order by `re`.`tipo_responsabilidad` ASC,`u`.`nombre_usuario` ASC separator ', ') AS `responsables`,count(`re`.`id_responsable`) AS `total_responsables` from (((((`Elementos` `e` left join `Ambientes` `a` on((`e`.`id_ambiente` = `a`.`id_ambiente`))) left join `Estado_Equipo` `ee` on((`e`.`codigo_equipo` = `ee`.`codigo_equipo`))) left join `Responsables_Equipo` `re` on(((`e`.`codigo_equipo` = `re`.`codigo_equipo`) and (`re`.`estado_responsabilidad` = 'Activo')))) left join `Usuarios` `u` on((`re`.`id_usuario` = `u`.`id_usuario`))) left join `Roles` `r` on((`u`.`id_rol` = `r`.`id_rol`))) group by `e`.`codigo_equipo`,`e`.`r_centro`,`e`.`consecutivo`,`e`.`tipo`,`e`.`modelo`,`a`.`nombre_ambiente`,`a`.`codigo_ambiente`,`ee`.`estado_operativo`,`e`.`estado_fisico` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Vista_Equipos_Disponibles`
--

/*!50001 DROP VIEW IF EXISTS `Vista_Equipos_Disponibles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Vista_Equipos_Disponibles` AS select `e`.`codigo_equipo` AS `codigo_equipo`,`e`.`r_centro` AS `r_centro`,`e`.`consecutivo` AS `consecutivo`,`e`.`tipo` AS `tipo`,`e`.`modelo` AS `modelo`,(case when (`c`.`es_componente` = true) then 'Componente Individual' else 'Equipo Completo' end) AS `nombre_tipo`,`a`.`nombre_ambiente` AS `nombre_ambiente`,`a`.`codigo_ambiente` AS `codigo_ambiente`,`a`.`tipo_ambiente` AS `tipo_ambiente`,`e`.`estado_fisico` AS `estado_fisico`,`e`.`fecha_adquisicion` AS `fecha_adquisicion` from (((`Elementos` `e` join `Categorias_Equipo` `c` on((`e`.`id_categoria` = `c`.`id_categoria`))) left join `Ambientes` `a` on((`e`.`id_ambiente` = `a`.`id_ambiente`))) join `Estado_Equipo` `ee` on((`e`.`codigo_equipo` = `ee`.`codigo_equipo`))) where ((`ee`.`estado_operativo` = 'Disponible') and (`e`.`estado_fisico` in ('Nuevo','Bueno','Regular'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Vista_Equipos_Por_Usuario`
--

/*!50001 DROP VIEW IF EXISTS `Vista_Equipos_Por_Usuario`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Vista_Equipos_Por_Usuario` AS select `u`.`id_usuario` AS `id_usuario`,`u`.`nombre_usuario` AS `nombre_usuario`,`u`.`cedula` AS `cedula`,`r`.`nombre_rol` AS `nombre_rol`,count(distinct `re`.`codigo_equipo`) AS `equipos_asignados`,group_concat(concat(`e`.`tipo`,' - ',coalesce(`e`.`consecutivo`,`e`.`r_centro`)) order by `re`.`fecha_asignacion` DESC separator ' | ') AS `detalle_equipos` from (((`Usuarios` `u` join `Roles` `r` on((`u`.`id_rol` = `r`.`id_rol`))) left join `Responsables_Equipo` `re` on(((`u`.`id_usuario` = `re`.`id_usuario`) and (`re`.`estado_responsabilidad` = 'Activo')))) left join `Elementos` `e` on((`re`.`codigo_equipo` = `e`.`codigo_equipo`))) where (`u`.`estado` = 'Activo') group by `u`.`id_usuario`,`u`.`nombre_usuario`,`u`.`cedula`,`r`.`nombre_rol` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Vista_Mantenimientos_Proximos`
--

/*!50001 DROP VIEW IF EXISTS `Vista_Mantenimientos_Proximos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Vista_Mantenimientos_Proximos` AS select `m`.`id_mantenimiento` AS `id_mantenimiento`,`e`.`codigo_equipo` AS `codigo_equipo`,`e`.`r_centro` AS `r_centro`,`e`.`consecutivo` AS `consecutivo`,`e`.`tipo` AS `tipo`,`m`.`tipo_mantenimiento` AS `tipo_mantenimiento`,`m`.`fecha_proximo` AS `fecha_proximo`,(to_days(`m`.`fecha_proximo`) - to_days(curdate())) AS `dias_restantes`,`a`.`nombre_ambiente` AS `nombre_ambiente`,`a`.`codigo_ambiente` AS `codigo_ambiente`,(case when ((to_days(`m`.`fecha_proximo`) - to_days(curdate())) <= 7) then 'Urgente' when ((to_days(`m`.`fecha_proximo`) - to_days(curdate())) <= 30) then 'Próximo' else 'Programado' end) AS `prioridad` from ((`Mantenimiento` `m` join `Elementos` `e` on((`m`.`codigo_equipo` = `e`.`codigo_equipo`))) left join `Ambientes` `a` on((`e`.`id_ambiente` = `a`.`id_ambiente`))) where ((`m`.`fecha_proximo` is not null) and (`m`.`fecha_proximo` >= curdate()) and (`m`.`estado_mantenimiento` in ('Programado','En Proceso'))) order by `m`.`fecha_proximo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Vista_Responsables_Actuales`
--

/*!50001 DROP VIEW IF EXISTS `Vista_Responsables_Actuales`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Vista_Responsables_Actuales` AS select `ra`.`id_responsabilidad_ambiente` AS `id_responsabilidad_ambiente`,`ra`.`id_ambiente` AS `id_ambiente`,`a`.`nombre_ambiente` AS `nombre_ambiente`,`a`.`codigo_ambiente` AS `codigo_ambiente`,`ra`.`id_usuario` AS `id_usuario`,`u`.`nombre_usuario` AS `nombre_usuario`,`u`.`cedula` AS `cedula`,`r`.`nombre_rol` AS `nombre_rol`,`ra`.`tipo_responsabilidad` AS `tipo_responsabilidad`,`ra`.`fecha_inicio` AS `fecha_inicio`,`ra`.`fecha_fin` AS `fecha_fin`,`ra`.`id_clase` AS `id_clase`,`c`.`nombre_clase` AS `nombre_clase`,`c`.`codigo_ficha` AS `codigo_ficha`,`c`.`fecha_clase` AS `fecha_clase`,`c`.`hora_inicio` AS `hora_inicio`,`c`.`hora_fin` AS `hora_fin`,(case when ((`ra`.`fecha_inicio` <= now()) and ((`ra`.`fecha_fin` is null) or (`ra`.`fecha_fin` >= now()))) then 'Activo' else 'Inactivo' end) AS `estado_actual` from ((((`Responsabilidades_Ambiente` `ra` join `Ambientes` `a` on((`ra`.`id_ambiente` = `a`.`id_ambiente`))) join `Usuarios` `u` on((`ra`.`id_usuario` = `u`.`id_usuario`))) left join `Roles` `r` on((`u`.`id_rol` = `r`.`id_rol`))) left join `Clases` `c` on((`ra`.`id_clase` = `c`.`id_clase`))) where (`ra`.`estado_responsabilidad` = 'Activa') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-29 15:11:29
